URL for accessing the static site

http://dlv36e6m8zyyu.cloudfront.net/index.html

In this project we have used AWS to deploy a staic website to cloud.
AWS services used-
S3
CloudFront
IAM